<?php
// פעולות מורה משותפות — לממשק המורה (teacher.php) ולשכבת הסוכנים (index.php).

require_once __DIR__ . '/db.php';

// קוד כיתה = 6 ספרות (קל לילדים; בלי אפס בהתחלה כדי שלא ייעלם בהעתקה)
function gen_code(PDO $db): string {
    for ($i = 0; $i < 40; $i++) {
        $code = (string)random_int(100000, 999999);
        $st = $db->prepare('SELECT 1 FROM classes WHERE code = ?');
        $st->execute([$code]);
        if (!$st->fetch()) return $code;
    }
    json_err('לא הצלחנו ליצור קוד ייחודי', 500);
    exit;
}

function t_register(array $b): array {
    $name = trim((string)($b['name'] ?? ''));
    $email = strtolower(trim((string)($b['email'] ?? '')));
    $pass = (string)($b['password'] ?? '');
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) json_err('שם ואימייל תקין נדרשים');
    if (strlen($pass) < 6) json_err('סיסמה קצרה מדי (לפחות 6 תווים)');
    $db = db();
    $st = $db->prepare('SELECT id FROM teachers WHERE email = ?');
    $st->execute([$email]);
    if ($st->fetch()) json_err('כתובת האימייל כבר רשומה — נסו להתחבר');
    $db->prepare('INSERT INTO teachers (name, email, pass_hash) VALUES (?, ?, ?)')
       ->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT)]);
    return ['token' => make_token('t', (int)$db->lastInsertId()), 'name' => $name, 'email' => $email];
}

function t_login(array $b): array {
    $email = strtolower(trim((string)($b['email'] ?? '')));
    $pass = (string)($b['password'] ?? '');
    $st = db()->prepare('SELECT id, name, pass_hash FROM teachers WHERE email = ?');
    $st->execute([$email]);
    $t = $st->fetch(PDO::FETCH_ASSOC);
    if (!$t || !$t['pass_hash'] || !password_verify($pass, $t['pass_hash'])) {
        json_err('אימייל או סיסמה שגויים', 401);
    }
    return ['token' => make_token('t', (int)$t['id']), 'name' => $t['name'], 'email' => $email];
}

// ── מסלולי כתיבה (שקפי TRACING) — מוקלטים בעורך #/trace-edit ──
// קריאה פתוחה לכולם; שמירה רק למורה-מנהלת (לפי אימייל).
const STROKE_ADMINS = ['chepti@gmail.com'];

function strokes_file(): string { return data_dir() . '/strokes.json'; }

function t_strokes(): array {
    $f = strokes_file();
    $d = is_file($f) ? json_decode((string)file_get_contents($f), true) : null;
    return ['strokes' => is_array($d) ? (object)$d : new stdClass()];
}

function t_is_stroke_admin(int $tid): bool {
    $st = db()->prepare('SELECT email FROM teachers WHERE id = ?');
    $st->execute([$tid]);
    return in_array(strtolower((string)$st->fetchColumn()), STROKE_ADMINS, true);
}

/** {glyph:"C", strokes:[[[x,y],...],...]} — מערך ריק מוחק את האות. נקודות מנורמלות 0..1 */
function t_save_strokes(int $tid, array $b): array {
    if (!t_is_stroke_admin($tid)) json_err('רק מנהלת התוכן יכולה לשמור מסלולי כתיבה', 403);
    $glyph = (string)($b['glyph'] ?? '');
    if (!preg_match('/^[A-Za-z]$/', $glyph)) json_err('אות אנגלית אחת (A–Z / a–z)');
    $clean = [];
    foreach ((array)($b['strokes'] ?? []) as $s) {
        $pts = [];
        foreach ((array)$s as $p) {
            if (!is_array($p) || count($p) < 2) continue;
            $pts[] = [round(max(0, min(1, (float)$p[0])), 3), round(max(0, min(1, (float)$p[1])), 3)];
        }
        if (count($pts) > 1) $clean[] = array_slice($pts, 0, 400);
    }
    $all = (array)t_strokes()['strokes'];
    if ($clean) $all[$glyph] = array_slice($clean, 0, 8); else unset($all[$glyph]);
    ksort($all);
    $f = strokes_file();
    file_put_contents($f . '.tmp', json_encode($all, JSON_UNESCAPED_UNICODE));
    rename($f . '.tmp', $f);
    return ['ok' => true, 'glyph' => $glyph, 'strokes' => count($clean), 'total' => count($all)];
}

function t_me(int $tid): array {
    $admin = t_is_stroke_admin($tid);
    return ['strokeAdmin' => $admin, 'admin' => $admin];
}

/**
 * סטטיסטיקות אדמין (רק למנהלת התוכן): סיכומים, מורים וכיתות, תחנות, ופעילות יומית לאורך זמן.
 * תאריכים לפי UTC (כמו שנשמרים ב-DB).
 */
function t_admin_stats(int $tid): array {
    if (!t_is_stroke_admin($tid)) json_err('אזור אדמין — למנהלת התוכן בלבד', 403);
    $db = db();
    $one = fn(string $sql) => (int)$db->query($sql)->fetchColumn();

    $totals = [
        'teachers' => $one('SELECT COUNT(*) FROM teachers'),
        'classes' => $one('SELECT COUNT(*) FROM classes'),
        'students' => $one('SELECT COUNT(*) FROM students'),
        'active7' => $one("SELECT COUNT(*) FROM students WHERE last_seen >= datetime('now','-7 days')"),
        'active30' => $one("SELECT COUNT(*) FROM students WHERE last_seen >= datetime('now','-30 days')"),
        'plays' => $one('SELECT COALESCE(SUM(n),0) FROM unit_plays'),
        'plays30' => $one("SELECT COALESCE(SUM(n),0) FROM unit_plays WHERE day >= date('now','-30 days')"),
        'results' => $one('SELECT COUNT(*) FROM slide_results'),
        'completed' => $one('SELECT COUNT(*) FROM positions WHERE completed = 1'),
    ];

    $teachers = $db->query("SELECT t.id, t.name, t.email, t.created_at,
            (SELECT COUNT(*) FROM classes c WHERE c.teacher_id = t.id) AS classes,
            (SELECT COUNT(*) FROM students s JOIN classes c ON c.id = s.class_id WHERE c.teacher_id = t.id) AS students,
            (SELECT COUNT(*) FROM students s JOIN classes c ON c.id = s.class_id WHERE c.teacher_id = t.id AND s.last_seen >= datetime('now','-30 days')) AS active30,
            (SELECT MAX(s.last_seen) FROM students s JOIN classes c ON c.id = s.class_id WHERE c.teacher_id = t.id) AS last_seen,
            (SELECT COUNT(*) FROM positions p JOIN students s ON s.id = p.student_id JOIN classes c ON c.id = s.class_id WHERE c.teacher_id = t.id AND p.completed = 1) AS completed
        FROM teachers t ORDER BY t.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
    $classes = $db->query("SELECT c.id, c.teacher_id, c.name, c.created_at,
            (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id) AS students,
            (SELECT MAX(s.last_seen) FROM students s WHERE s.class_id = c.id) AS last_seen
        FROM classes c ORDER BY c.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

    $units = [];
    foreach ($db->query("SELECT unit_id, SUM(n) AS plays, SUM(CASE WHEN day >= date('now','-30 days') THEN n ELSE 0 END) AS plays30 FROM unit_plays GROUP BY unit_id") as $r) {
        $units[$r['unit_id']] = ['plays' => (int)$r['plays'], 'plays30' => (int)$r['plays30']];
    }
    foreach ($db->query('SELECT unit_id, COUNT(*) AS started, SUM(completed) AS completed, AVG(CASE WHEN completed = 1 THEN stars END) AS stars FROM positions GROUP BY unit_id') as $r) {
        $units[$r['unit_id']] = ($units[$r['unit_id']] ?? ['plays' => 0, 'plays30' => 0]) + [
            'started' => (int)$r['started'], 'completed' => (int)$r['completed'],
            'avgStars' => $r['stars'] === null ? null : round((float)$r['stars'], 1),
        ];
    }

    // פעילות יומית: כניסות (כולל אורחים), תלמידים פעילים (שענו על שקף), תשובות, תלמידים / מורים חדשים
    $days = [];
    $put = function (string $sql, string $key) use ($db, &$days) {
        foreach ($db->query($sql) as $r) {
            if (!$r['d']) continue;
            $days[$r['d']] ??= ['plays' => 0, 'active' => 0, 'results' => 0, 'newStudents' => 0, 'newTeachers' => 0];
            $days[$r['d']][$key] = (int)$r['n'];
        }
    };
    $put('SELECT day AS d, SUM(n) AS n FROM unit_plays GROUP BY day', 'plays');
    $put('SELECT date(created_at) AS d, COUNT(DISTINCT student_id) AS n FROM slide_results GROUP BY d', 'active');
    $put('SELECT date(created_at) AS d, COUNT(*) AS n FROM slide_results GROUP BY d', 'results');
    $put('SELECT date(created_at) AS d, COUNT(*) AS n FROM students GROUP BY d', 'newStudents');
    $put('SELECT date(created_at) AS d, COUNT(*) AS n FROM teachers GROUP BY d', 'newTeachers');
    ksort($days);
    $timeline = [];
    foreach ($days as $d => $v) $timeline[] = ['day' => $d] + $v;

    $int = fn(array $r, array $keys) => array_merge($r, array_combine($keys, array_map(fn($k) => (int)$r[$k], $keys)));
    return [
        'generatedAt' => gmdate('c'),
        'totals' => $totals,
        'teachers' => array_map(fn($r) => $int($r, ['id', 'classes', 'students', 'active30', 'completed']), $teachers),
        'classes' => array_map(fn($r) => $int($r, ['id', 'teacher_id', 'students']), $classes),
        'units' => (object)$units,
        'timeline' => $timeline,
    ];
}

function class_row(array $r): array {
    return [
        'id' => (int)$r['id'],
        'name' => $r['name'],
        'code' => $r['code'],
        'freeNav' => (bool)$r['free_nav'],
        'showFriends' => (bool)($r['show_friends'] ?? 0),
        'mapStyle' => ($r['map_style'] ?? 'journey') === 'stars' ? 'stars' : 'journey',
        'videoSource' => ($r['video_source'] ?? 'youtube') === 'drive' ? 'drive' : 'youtube',
        'students' => (int)($r['students'] ?? 0),
    ];
}

/** חוויית המפה של הכיתה: journey (מסע הרפתקה) / stars (מפה פשוטה). התלמיד יכול להחליף אצלו */
function t_set_map_style(int $tid, array $b): array {
    $c = t_find_class($tid, $b);
    $style = ($b['style'] ?? '') === 'stars' ? 'stars' : 'journey';
    db()->prepare('UPDATE classes SET map_style = ? WHERE id = ?')->execute([$style, $c['id']]);
    return ['ok' => true, 'classId' => (int)$c['id'], 'mapStyle' => $style];
}

/** מקור הסרטונים לכיתה: youtube / drive (כשיוטיוב מסונן בבית הספר). התלמיד יכול להחליף במכשיר שלו */
function t_set_video_source(int $tid, array $b): array {
    $c = t_find_class($tid, $b);
    $src = ($b['source'] ?? '') === 'drive' ? 'drive' : 'youtube';
    db()->prepare('UPDATE classes SET video_source = ? WHERE id = ?')->execute([$src, $c['id']]);
    return ['ok' => true, 'classId' => (int)$c['id'], 'videoSource' => $src];
}

/** חברים על המפה: מפעילים / מכבים לכיתה (ברירת מחדל בכיתה חדשה: מופעל) */
function t_set_friends(int $tid, array $b): array {
    $c = t_find_class($tid, $b);
    $on = !empty($b['on']) ? 1 : 0;
    db()->prepare('UPDATE classes SET show_friends = ? WHERE id = ?')->execute([$on, $c['id']]);
    return ['ok' => true, 'classId' => (int)$c['id'], 'showFriends' => (bool)$on];
}

function t_classes(int $tid): array {
    $st = db()->prepare('SELECT c.id, c.name, c.code, c.free_nav, c.show_friends, c.map_style, c.video_source,
            (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id) AS students
        FROM classes c WHERE c.teacher_id = ? ORDER BY c.id DESC');
    $st->execute([$tid]);
    return array_map('class_row', $st->fetchAll(PDO::FETCH_ASSOC));
}

function t_create_class(int $tid, array $b): array {
    $name = trim((string)($b['name'] ?? ''));
    if ($name === '') json_err('חסר שם כיתה');
    $db = db();
    $code = gen_code($db);
    // חברים על המפה — מופעל כברירת מחדל בכיתה חדשה (המורה יכולה לכבות)
    $db->prepare('INSERT INTO classes (teacher_id, name, code, show_friends) VALUES (?, ?, ?, 1)')->execute([$tid, $name, $code]);
    return ['id' => (int)$db->lastInsertId(), 'name' => $name, 'code' => $code, 'freeNav' => true, 'showFriends' => true, 'students' => 0];
}

/** איתור כיתה של המורה לפי id / קוד / חלק מהשם. בהתנגשות — רשימת מועמדים */
function t_find_class(int $tid, array $b): array {
    $db = db();
    if (!empty($b['classId']) || !empty($b['id'])) {
        $st = $db->prepare('SELECT * FROM classes WHERE id = ? AND teacher_id = ?');
        $st->execute([(int)($b['classId'] ?? $b['id']), $tid]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) json_err('כיתה לא נמצאה', 404);
        return $r;
    }
    $m = trim((string)($b['match'] ?? $b['code'] ?? ''));
    if ($m === '') json_err('חסר classId או match');
    $st = $db->prepare('SELECT * FROM classes WHERE teacher_id = ? AND (code = ? OR name LIKE ?)');
    $st->execute([$tid, $m, '%' . $m . '%']);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    if (count($rows) === 1) return $rows[0];
    if (!$rows) json_err("לא נמצאה כיתה שמתאימה ל-\"$m\"", 404);
    json_err('נמצאו כמה כיתות — ציינו classId', 409, ['candidates' => array_map('class_row', $rows)]);
    exit;
}

function t_find_student(int $classId, array $b): array {
    $db = db();
    if (!empty($b['studentId'])) {
        $st = $db->prepare('SELECT * FROM students WHERE id = ? AND class_id = ?');
        $st->execute([(int)$b['studentId'], $classId]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) json_err('תלמיד לא נמצא', 404);
        return $r;
    }
    $m = trim((string)($b['student'] ?? ''));
    if ($m === '') json_err('חסר studentId או student');
    $st = $db->prepare('SELECT * FROM students WHERE class_id = ? AND nickname LIKE ?');
    $st->execute([$classId, '%' . $m . '%']);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) if ($r['nickname'] === $m) return $r;
    if (count($rows) === 1) return $rows[0];
    if (!$rows) json_err("לא נמצא תלמיד שמתאים ל-\"$m\"", 404);
    json_err('נמצאו כמה תלמידים — ציינו studentId', 409, ['candidates' => array_map(
        fn($r) => ['id' => (int)$r['id'], 'nickname' => $r['nickname'], 'emoji' => $r['emoji']], $rows)]);
    exit;
}

function t_set_free(int $tid, array $b): array {
    $c = t_find_class($tid, $b);
    $free = !empty($b['free']) ? 1 : 0;
    db()->prepare('UPDATE classes SET free_nav = ? WHERE id = ?')->execute([$free, $c['id']]);
    return ['ok' => true, 'classId' => (int)$c['id'], 'freeNav' => (bool)$free];
}

function t_rename_class(int $tid, array $b): array {
    $c = t_find_class($tid, $b);
    $name = trim((string)($b['name'] ?? ''));
    if ($name === '') json_err('חסר שם חדש');
    db()->prepare('UPDATE classes SET name = ? WHERE id = ?')->execute([$name, $c['id']]);
    return ['ok' => true, 'classId' => (int)$c['id'], 'name' => $name];
}

function t_delete_student(int $tid, array $b): array {
    $c = t_find_class($tid, $b);
    $s = t_find_student((int)$c['id'], $b);
    db()->prepare('DELETE FROM students WHERE id = ?')->execute([$s['id']]);
    return ['ok' => true, 'deleted' => ['id' => (int)$s['id'], 'nickname' => $s['nickname']]];
}

/** איפוס התקדמות של תלמיד ביחידה אחת (unitId) או בכולן */
function t_reset_student(int $tid, array $b): array {
    $c = t_find_class($tid, $b);
    $s = t_find_student((int)$c['id'], $b);
    $db = db();
    $unit = (string)($b['unitId'] ?? '');
    if ($unit !== '') {
        $db->prepare('DELETE FROM positions WHERE student_id = ? AND unit_id = ?')->execute([$s['id'], $unit]);
        $db->prepare('DELETE FROM slide_results WHERE student_id = ? AND unit_id = ?')->execute([$s['id'], $unit]);
    } else {
        foreach (['positions', 'slide_results', 'skill_stats'] as $t) {
            $db->prepare("DELETE FROM $t WHERE student_id = ?")->execute([$s['id']]);
        }
    }
    return ['ok' => true, 'studentId' => (int)$s['id'], 'unitId' => $unit ?: 'all'];
}

/** מפת חום: כל תלמיד + שליטה לפי צליל + מיקום בכל יחידה */
function t_heatmap(int $tid, array $b): array {
    $c = t_find_class($tid, $b);
    $st = db()->prepare('SELECT id, nickname, emoji, last_seen FROM students WHERE class_id = ? ORDER BY nickname');
    $st->execute([$c['id']]);
    $out = [];
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $s) {
        $p = student_progress((int)$s['id']);
        $out[] = [
            'id' => (int)$s['id'],
            'nickname' => $s['nickname'],
            'emoji' => $s['emoji'],
            'lastSeen' => $s['last_seen'],
        ] + $p;
    }
    return ['class' => class_row($c), 'students' => $out];
}
